<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$stmt->close();
$conn->close();
?>

<?php include 'header.php'; ?>

<!-- Основное содержимое страницы -->
<section class="container py-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Личный кабинет</h2>
            <form action="update_profile.php" method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Имя</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo $user['name']; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Электронная почта</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email']; ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Сохранить изменения</button>
            </form>

            <!-- Форма для отзыва -->
            <h3 class="mt-5 mb-4">Оставить отзыв</h3>
            <?php if (isset($_GET['success'])): ?>
                <div class="alert alert-success" role="alert">
                    Ваш отзыв успешно отправлен и ожидает модерации!
                </div>
            <?php endif; ?>
            <form action="submit_review.php" method="POST">
                <div class="mb-3">
                    <label for="review_text" class="form-label">Отзыв</label>
                    <textarea class="form-control" id="review_text" name="review_text" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Отправить отзыв</button>
            </form>
        </div>
    </div>
</section>

<?php include 'footer.php'; ?>

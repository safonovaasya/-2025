<?php
include 'header.php';
include 'db.php';

// Проверка, является ли пользователь администратором
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: index.php'); // Перенаправляем неавторизованных пользователей
    exit;
}

// Обработка формы добавления квартиры
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_apartment'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $address = $_POST['address'];
    $floor = $_POST['floor'];
    $area = $_POST['area'];
    $rooms = $_POST['rooms'];
    $description = $_POST['description'];
    $type = $_POST['type'];
    $action = $_POST['action'];

    // Вставка данных в таблицу apartments
    $query = "INSERT INTO apartments (name, price, address, floor, area, rooms, description, type, action)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sdssdisss', $name, $price, $address, $floor, $area, $rooms, $description, $type, $action);

    if ($stmt->execute()) {
        $apartment_id = $stmt->insert_id; // Получаем ID добавленной квартиры

        // Обработка загрузки фотографий
        if (!empty($_FILES['photos']['name'][0])) {
            $upload_success = true;
            foreach ($_FILES['photos']['tmp_name'] as $key => $tmp_name) {
                $photo_name = $_FILES['photos']['name'][$key];
                $photo_path = 'img/' . basename($photo_name);

                // Перемещаем файл в папку img
                if (move_uploaded_file($tmp_name, $photo_path)) {
                    // Вставляем путь к фото в таблицу photos
                    $photo_query = "INSERT INTO photos (apartment_id, photo_path) VALUES (?, ?)";
                    $photo_stmt = $conn->prepare($photo_query);
                    $photo_stmt->bind_param('is', $apartment_id, $photo_path);
                    if (!$photo_stmt->execute()) {
                        $upload_success = false;
                        break;
                    }
                } else {
                    $upload_success = false;
                    break;
                }
            }

            if ($upload_success) {
                echo '<div class="alert alert-success" role="alert">Квартира и фотографии успешно добавлены!</div>';
            } else {
                echo '<div class="alert alert-danger" role="alert">Ошибка при загрузке фотографий.</div>';
            }
        } else {
            echo '<div class="alert alert-warning" role="alert">Квартира добавлена, но фотографии не загружены.</div>';
        }
    } else {
        echo '<div class="alert alert-danger" role="alert">Ошибка при добавлении квартиры: ' . $stmt->error . '</div>';
    }
}

// Обработка удаления квартиры
if (isset($_GET['delete'])) {
    $apartment_id = $_GET['delete'];
    $delete_query = "DELETE FROM apartments WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param('i', $apartment_id);
    if ($stmt->execute()) {
        echo '<div class="alert alert-success" role="alert">Квартира успешно удалена!</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Ошибка при удалении квартиры: ' . $stmt->error . '</div>';
    }
}

// Обработка формы редактирования квартиры
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_apartment'])) {
    $apartment_id = $_POST['apartment_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $address = $_POST['address'];
    $floor = $_POST['floor'];
    $area = $_POST['area'];
    $rooms = $_POST['rooms'];
    $description = $_POST['description'];
    $type = $_POST['type'];
    $action = $_POST['action'];

    $update_query = "UPDATE apartments SET name = ?, price = ?, address = ?, floor = ?, area = ?, rooms = ?, description = ?, type = ?, action = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('sdssdisssi', $name, $price, $address, $floor, $area, $rooms, $description, $type, $action, $apartment_id);

    if ($stmt->execute()) {
        echo '<div class="alert alert-success" role="alert">Квартира успешно обновлена!</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Ошибка при обновлении квартиры: ' . $stmt->error . '</div>';
    }
}

// Обработка модерации отзывов
if (isset($_GET['approve_review'])) {
    $review_id = $_GET['approve_review'];
    $approve_query = "UPDATE reviews SET status = 'approved' WHERE id = ?";
    $stmt = $conn->prepare($approve_query);
    $stmt->bind_param('i', $review_id);
    if ($stmt->execute()) {
        echo '<div class="alert alert-success" role="alert">Отзыв успешно одобрен!</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Ошибка при одобрении отзыва: ' . $stmt->error . '</div>';
    }
}

if (isset($_GET['delete_review'])) {
    $review_id = $_GET['delete_review'];
    $delete_query = "DELETE FROM reviews WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param('i', $review_id);
    if ($stmt->execute()) {
        echo '<div class="alert alert-success" role="alert">Отзыв успешно удален!</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Ошибка при удалении отзыва: ' . $stmt->error . '</div>';
    }
}

// Получение списка всех квартир
$apartments_query = "SELECT * FROM apartments";
$apartments_result = $conn->query($apartments_query);

// Получение списка отзывов для модерации
$reviews_query = "SELECT * FROM reviews WHERE status = 'pending'";
$reviews_result = $conn->query($reviews_query);

// Получение всех отзывов
$all_reviews_query = "SELECT * FROM reviews";
$all_reviews_result = $conn->query($all_reviews_query);
?>

<main>
  <div class="container my-5">
    <h2 class="text-center mb-4">Админ-панель</h2>

    <!-- Форма добавления новой квартиры -->
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Добавить новую квартиру</h5>
            <form method="POST" action="admin_panel.php" enctype="multipart/form-data">
              <div class="mb-3">
                <label for="name" class="form-label">Название</label>
                <input type="text" class="form-control" id="name" name="name" required>
              </div>
              <div class="mb-3">
                <label for="price" class="form-label">Цена</label>
                <input type="number" class="form-control" id="price" name="price" required>
              </div>
              <div class="mb-3">
                <label for="address" class="form-label">Адрес</label>
                <input type="text" class="form-control" id="address" name="address" required>
              </div>
              <div class="mb-3">
                <label for="floor" class="form-label">Этаж</label>
                <input type="number" class="form-control" id="floor" name="floor" required>
              </div>
              <div class="mb-3">
                <label for="area" class="form-label">Площадь (м²)</label>
                <input type="number" step="0.01" class="form-control" id="area" name="area" required>
              </div>
              <div class="mb-3">
                <label for="rooms" class="form-label">Количество комнат</label>
                <input type="number" class="form-control" id="rooms" name="rooms" required>
              </div>
              <div class="mb-3">
                <label for="description" class="form-label">Описание</label>
                <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
              </div>
              <div class="mb-3">
                <label for="type" class="form-label">Тип недвижимости</label>
                <select class="form-select" id="type" name="type" required>
                  <option value="apartment">Квартира</option>
                  <option value="house">Дом</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="action" class="form-label">Действие</label>
                <select class="form-select" id="action" name="action" required>
                  <option value="rent">Снять</option>
                  <option value="buy">Купить</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="photos" class="form-label">Фотографии</label>
                <div id="photo-fields">
                  <input type="file" class="form-control mb-2" name="photos[]" required>
                </div>
                <button type="button" id="add-photo" class="btn btn-primary">Добавить ещё фото</button>
              </div>
              <button type="submit" name="add_apartment" class="btn btn-primary">Добавить квартиру</button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Список квартир с возможностью редактирования и удаления -->
    <div class="row mt-5">
      <div class="col-md-12">
        <h3 class="text-center mb-4">Список квартир</h3>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Название</th>
                <th>Цена</th>
                <th>Адрес</th>
                <th>Этаж</th>
                <th>Площадь</th>
                <th>Комнаты</th>
                <th>Тип</th>
                <th>Действие</th>
                <th>Описание</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($apartment = $apartments_result->fetch_assoc()): ?>
                <tr>
                  <td><?php echo $apartment['id']; ?></td>
                  <td><?php echo $apartment['name']; ?></td>
                  <td><?php echo $apartment['price']; ?></td>
                  <td><?php echo $apartment['address']; ?></td>
                  <td><?php echo $apartment['floor']; ?></td>
                  <td><?php echo $apartment['area']; ?></td>
                  <td><?php echo $apartment['rooms']; ?></td>
                  <td><?php echo $apartment['type']; ?></td>
                  <td><?php echo $apartment['action']; ?></td>
                  <td><?php echo $apartment['description']; ?></td>
                  <td>
                    <a href="edit_apartment.php?id=<?php echo $apartment['id']; ?>" class="btn btn-primary btn-sm">Редактировать</a>
                    <a href="admin_panel.php?delete=<?php echo $apartment['id']; ?>" class="btn btn-primary btn-sm" onclick="return confirm('Вы уверены, что хотите удалить эту квартиру?');">Удалить</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Список отзывов для модерации -->
    <div class="row mt-5">
      <div class="col-md-12">
        <h3 class="text-center mb-4">Отзывы для модерации</h3>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Имя</th>
                <th>Отзыв</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($review = $reviews_result->fetch_assoc()): ?>
                <tr>
                  <td><?php echo $review['id']; ?></td>
                  <td><?php echo $review['name']; ?></td>
                  <td><?php echo $review['review_text']; ?></td>
                  <td>
                    <a href="admin_panel.php?approve_review=<?php echo $review['id']; ?>" class="btn btn-primary btn-sm">Одобрить</a>
                    <a href="admin_panel.php?delete_review=<?php echo $review['id']; ?>" class="btn btn-primary btn-sm" onclick="return confirm('Вы уверены, что хотите удалить этот отзыв?');">Удалить</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- Список всех отзывов -->
    <div class="row mt-5">
      <div class="col-md-12">
        <h3 class="text-center mb-4">Все отзывы</h3>
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Имя</th>
                <th>Отзыв</th>
                <th>Статус</th>
                <th>Действия</th>
              </tr>
            </thead>
            <tbody>
              <?php while ($review = $all_reviews_result->fetch_assoc()): ?>
                <tr>
                  <td><?php echo $review['id']; ?></td>
                  <td><?php echo $review['name']; ?></td>
                  <td><?php echo $review['review_text']; ?></td>
                  <td><?php echo $review['status']; ?></td>
                  <td>
                    <a href="admin_panel.php?delete_review=<?php echo $review['id']; ?>" class="btn btn-primary btn-sm" onclick="return confirm('Вы уверены, что хотите удалить этот отзыв?');">Удалить</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const photoFields = document.getElementById('photo-fields');
    const addPhotoButton = document.getElementById('add-photo');

    addPhotoButton.addEventListener('click', function () {
      const newInput = document.createElement('input');
      newInput.type = 'file';
      newInput.className = 'form-control mb-2';
      newInput.name = 'photos[]';
      photoFields.appendChild(newInput);
    });
  });
</script>

<style>
  .table-responsive {
    overflow-x: auto;
  }
</style>

<?php include 'footer.php'; ?>

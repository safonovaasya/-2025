<?php
include 'header.php';
include 'db.php';

// Проверка, является ли пользователь администратором
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: index.php'); // Перенаправляем неавторизованных пользователей
    exit;
}

// Получение информации о квартире для редактирования
if (isset($_GET['id'])) {
    $apartment_id = $_GET['id'];
    $query = "SELECT * FROM apartments WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $apartment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $apartment = $result->fetch_assoc();

    if (!$apartment) {
        die("Квартира не найдена");
    }
} else {
    die("ID квартиры не указан");
}

// Получение фотографий квартиры
$photos_query = "SELECT * FROM photos WHERE apartment_id = ?";
$photos_stmt = $conn->prepare($photos_query);
$photos_stmt->bind_param('i', $apartment_id);
$photos_stmt->execute();
$photos_result = $photos_stmt->get_result();

// Обработка формы редактирования квартиры
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Обновление данных квартиры
    $name = $_POST['name'];
    $price = $_POST['price'];
    $address = $_POST['address'];
    $floor = $_POST['floor'];
    $area = $_POST['area'];
    $rooms = $_POST['rooms'];
    $description = $_POST['description'];
    $type = $_POST['type'];
    $action = $_POST['action'];

    $update_query = "UPDATE apartments SET name = ?, price = ?, address = ?, floor = ?, area = ?, rooms = ?, description = ?, type = ?, action = ? WHERE id = ?";
    $stmt = $conn->prepare($update_query);
    $stmt->bind_param('sdssdisssi', $name, $price, $address, $floor, $area, $rooms, $description, $type, $action, $apartment_id);

    if ($stmt->execute()) {
        echo '<div class="alert alert-success" role="alert">Данные квартиры успешно обновлены!</div>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Ошибка при обновлении данных квартиры: ' . $stmt->error . '</div>';
    }

    // Удаление выбранных фотографий
    if (isset($_POST['delete_photos'])) {
        foreach ($_POST['delete_photos'] as $photo_id) {
            $delete_query = "DELETE FROM photos WHERE id = ?";
            $delete_stmt = $conn->prepare($delete_query);
            $delete_stmt->bind_param('i', $photo_id);
            if (!$delete_stmt->execute()) {
                echo '<div class="alert alert-danger" role="alert">Ошибка при удалении фотографии: ' . $delete_stmt->error . '</div>';
            }
        }
    }

    // Загрузка новых фотографий
    if (!empty($_FILES['new_photos']['name'][0])) {
        $upload_success = true;
        foreach ($_FILES['new_photos']['tmp_name'] as $key => $tmp_name) {
            $photo_name = $_FILES['new_photos']['name'][$key];
            $photo_path = 'img/' . basename($photo_name);

            if (move_uploaded_file($tmp_name, $photo_path)) {
                $photo_query = "INSERT INTO photos (apartment_id, photo_path) VALUES (?, ?)";
                $photo_stmt = $conn->prepare($photo_query);
                $photo_stmt->bind_param('is', $apartment_id, $photo_path);
                if (!$photo_stmt->execute()) {
                    $upload_success = false;
                    echo '<div class="alert alert-danger" role="alert">Ошибка при загрузке фотографии: ' . $photo_stmt->error . '</div>';
                }
            } else {
                $upload_success = false;
                echo '<div class="alert alert-danger" role="alert">Ошибка при перемещении файла.</div>';
            }
        }

        if ($upload_success) {
            echo '<div class="alert alert-success" role="alert">Новые фотографии успешно загружены!</div>';
        }
    }
}
?>

<main>
  <div class="container my-5">
    <h2 class="text-center mb-4">Редактирование квартиры</h2>

    <!-- Форма редактирования квартиры -->
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Редактировать квартиру</h5>
            <form method="POST" action="edit_apartment.php?id=<?php echo $apartment['id']; ?>" enctype="multipart/form-data">
              <!-- Поля для редактирования данных квартиры -->
              <div class="mb-3">
                <label for="name" class="form-label">Название</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo $apartment['name']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="price" class="form-label">Цена</label>
                <input type="number" class="form-control" id="price" name="price" value="<?php echo $apartment['price']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="address" class="form-label">Адрес</label>
                <input type="text" class="form-control" id="address" name="address" value="<?php echo $apartment['address']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="floor" class="form-label">Этаж</label>
                <input type="number" class="form-control" id="floor" name="floor" value="<?php echo $apartment['floor']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="area" class="form-label">Площадь (м²)</label>
                <input type="number" step="0.01" class="form-control" id="area" name="area" value="<?php echo $apartment['area']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="rooms" class="form-label">Количество комнат</label>
                <input type="number" class="form-control" id="rooms" name="rooms" value="<?php echo $apartment['rooms']; ?>" required>
              </div>
              <div class="mb-3">
                <label for="description" class="form-label">Описание</label>
                <textarea class="form-control" id="description" name="description" rows="3" required><?php echo $apartment['description']; ?></textarea>
              </div>
              <div class="mb-3">
                <label for="type" class="form-label">Тип недвижимости</label>
                <select class="form-select" id="type" name="type" required>
                  <option value="apartment" <?php echo $apartment['type'] === 'apartment' ? 'selected' : ''; ?>>Квартира</option>
                  <option value="house" <?php echo $apartment['type'] === 'house' ? 'selected' : ''; ?>>Дом</option>
                </select>
              </div>
              <div class="mb-3">
                <label for="action" class="form-label">Действие</label>
                <select class="form-select" id="action" name="action" required>
                  <option value="rent" <?php echo $apartment['action'] === 'rent' ? 'selected' : ''; ?>>Снять</option>
                  <option value="buy" <?php echo $apartment['action'] === 'buy' ? 'selected' : ''; ?>>Купить</option>
                </select>
              </div>

              <!-- Управление фотографиями -->
              <div class="mb-3">
                <label class="form-label">Текущие фотографии</label>
                <?php while ($photo = $photos_result->fetch_assoc()): ?>
                  <div class="d-flex align-items-center mb-2">
                    <img src="<?php echo $photo['photo_path']; ?>" alt="Фото квартиры" style="max-width: 100px; margin-right: 10px;">
                    <input type="checkbox" name="delete_photos[]" value="<?php echo $photo['id']; ?>"> Удалить
                  </div>
                <?php endwhile; ?>
              </div>

              <!-- Загрузка новых фотографий -->
              <div class="mb-3">
                <label for="new_photos" class="form-label">Добавить новые фотографии</label>
                <input type="file" class="form-control" name="new_photos[]" multiple>
              </div>

              <button type="submit" name="edit_apartment" class="btn btn-primary">Сохранить изменения</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<?php include 'footer.php'; ?>
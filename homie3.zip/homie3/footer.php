<footer class="footer text-white py-4">
  <div class="container">
    <div class="row align-items-center text-center">
      <div class="col">
        <div class="topbarElements d-inline-flex align-items-center">
          <div>&#x27A4;</div>
          <div class="text-start d-md-block d-none ms-2">
            <h5 class="p-0 m-0">Офис</h5>
            <p class="p-0 m-0 text-secondary">г. Алейск, ул. Ширшова, д. 3</p>
          </div>
        </div>
      </div>
      <div class="col border-start border-end">
        <div class="topbarElements d-inline-flex align-items-center">
          <div>&#x270E;</div>
          <div class="text-start d-md-block d-none ms-2">
            <h5 class="p-0 m-0">Электронная почта</h5>
            <a href="mailto:homie@gmail.com" class="p-0 m-0 text-secondary text-decoration-none">homie@gmail.com</a>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="topbarElements d-inline-flex align-items-center">
          <div>&#x260F;</div>
          <div class="text-start d-md-block d-none ms-2">
            <h5 class="p-0 m-0">Телефон</h5>
            <a href="tel:+79139656654" class="p-0 m-0 text-secondary text-decoration-none">+7 (913) 965-66-54</a>
          </div>
        </div>
      </div>
    </div>
    <div class="row mt-4">
      <div class="col text-center">
        <p class="text-secondary mb-0">&copy; 2025 Homie. Все права защищены.</p>
      </div>
    </div>
  </div>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
  flatpickr("#viewing_date", {
    enableTime: true,
    dateFormat: "Y-m-d H:i",
    minDate: "today",
  });
</script>
</footer>

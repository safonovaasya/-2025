<?php
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $review_text = $_POST['review_text'];

    // Получаем имя пользователя из базы данных
    $sql = "SELECT name FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $name = $user['name'];

    $query = "INSERT INTO reviews (name, review_text) VALUES (?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $name, $review_text);

    if ($stmt->execute()) {
        header("Location: profile.php?success=true");
        exit();
    } else {
        echo "Ошибка при добавлении отзыва: " . $stmt->error;
    }
}
?>

<?php
include 'header.php';
include 'db.php';

// Проверка, является ли пользователь администратором
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: index.php');
    exit;
}

$admin_id = $_SESSION['user_id'];

// Получение списка пользователей, с которыми есть переписка
$users_query = "SELECT DISTINCT u.id, u.name FROM users u JOIN messages m ON u.id = m.sender_id WHERE m.receiver_id = ?";
$stmt = $conn->prepare($users_query);
$stmt->bind_param('i', $admin_id);
$stmt->execute();
$users_result = $stmt->get_result();

// Получение сообщений для выбранного пользователя
$selected_user_id = isset($_GET['user_id']) ? $_GET['user_id'] : null;
$messages_result = null;

if ($selected_user_id) {
    $messages_query = "SELECT m.*, a.name AS apartment_name, a.address AS apartment_address 
                       FROM messages m 
                       LEFT JOIN apartments a ON m.apartment_id = a.id 
                       WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?) 
                       ORDER BY m.created_at ASC";
    $stmt = $conn->prepare($messages_query);
    $stmt->bind_param('iiii', $admin_id, $selected_user_id, $selected_user_id, $admin_id);
    $stmt->execute();
    $messages_result = $stmt->get_result();
}
?>

<main>
  <div class="container my-5">
    <h2 class="text-center mb-4">Чат с пользователями</h2>

    <!-- Список пользователей -->
    <div class="row">
      <div class="col-md-4">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Пользователи</h5>
            <ul class="list-group">
              <?php while ($user = $users_result->fetch_assoc()): ?>
                <li class="list-group-item <?php echo $selected_user_id == $user['id'] ? 'active' : ''; ?>">
                    <a href="chat.php?user_id=<?php echo $user['id']; ?>" class="text-decoration-none">
                        <?php echo htmlspecialchars($user['name']); ?>
                    </a>
                </li>
              <?php endwhile; ?>
            </ul>
          </div>
        </div>
      </div>

      <!-- Сообщения и форма отправки -->
      <div class="col-md-8">
        <?php if ($selected_user_id): ?>
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Сообщения</h5>
              <div id="messages-list" class="list-group mb-3">
                <?php while ($message = $messages_result->fetch_assoc()): ?>
                  <div class="list-group-item <?php echo $message['sender_id'] == $admin_id ? 'text-end' : 'text-start'; ?>">
                    <?php if ($message['apartment_name']): ?>
                      <div class="mb-2">
                        <strong>Квартира:</strong> <?php echo htmlspecialchars($message['apartment_name']); ?>
                        <br>
                        <strong>Адрес:</strong> <?php echo htmlspecialchars($message['apartment_address']); ?>
                      </div>
                    <?php endif; ?>
                    <p><?php echo htmlspecialchars($message['message']); ?></p>
                    <small class="text-muted"><?php echo $message['created_at']; ?></small>
                  </div>
                <?php endwhile; ?>
              </div>
              <form id="chat-form">
                <div class="mb-3">
                  <label for="message" class="form-label">Ваше сообщение</label>
                  <textarea class="form-control" id="message" name="message" rows="1" required></textarea>
                </div>
                <input type="hidden" name="receiver_id" value="<?php echo $selected_user_id; ?>">
                <button type="submit" class="btn btn-primary">Отправить</button>
              </form>
            </div>
          </div>
        <?php else: ?>
          <div class="alert alert-danger" role="alert">Выберите пользователя для начала чата.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</main>

<script>
  // AJAX для отправки сообщения
  document.getElementById('chat-form').addEventListener('submit', function (e) {
    e.preventDefault(); // Отменяем стандартную отправку формы

    const messageInput = document.getElementById('message');
    const message = messageInput.value.trim();
    const receiverId = document.querySelector('input[name="receiver_id"]').value;

    if (message === '') {
      alert('Введите сообщение');
      return;
    }

    // Отправляем сообщение через AJAX
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'send_message.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function () {
      if (xhr.status === 200) {
        // Очищаем поле ввода
        messageInput.value = '';

        // Добавляем новое сообщение в список
        const messagesList = document.getElementById('messages-list');
        const newMessage = document.createElement('div');
        newMessage.className = 'list-group-item text-end';
        newMessage.innerHTML = `
          <p>${message}</p>
          <small class="text-muted">Только что</small>
        `;
        messagesList.appendChild(newMessage);

        // Прокручиваем список сообщений вниз
        messagesList.scrollTop = messagesList.scrollHeight;
      } else {
        alert('Ошибка при отправке сообщения');
      }
    };
    xhr.send(`message=${encodeURIComponent(message)}&receiver_id=${receiverId}`);
  });
</script>

<?php include 'footer.php'; ?>
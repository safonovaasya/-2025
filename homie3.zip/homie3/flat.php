<?php
include 'header.php';
include 'db.php';

// Получение информации о квартире
$apartment_id = $_GET['id'];
$query = "SELECT * FROM apartments WHERE id = $apartment_id";
$apartment_result = $conn->query($query);
$apartment = $apartment_result->fetch_assoc();

if (!$apartment) {
    die("Квартира не найдена");
}

// Проверка, добавлена ли квартира в избранное
$is_favorite = false;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $favorite_query = "SELECT id FROM favorites WHERE user_id = $user_id AND apartment_id = $apartment_id";
    $favorite_result = $conn->query($favorite_query);
    $is_favorite = $favorite_result->num_rows > 0;
}

// Получение фотографий квартиры
$photos_query = "SELECT photo_path FROM photos WHERE apartment_id = $apartment_id";
$photos_result = $conn->query($photos_query);
?>

<main class="container my-5">
  <div class="row">
    <div class="col-md-6 mb-4">
      <div class="property-slider">
        <?php while ($photo = $photos_result->fetch_assoc()): ?>
          <div class="slider-image"><img src="<?php echo $photo['photo_path']; ?>" alt="Фото"></div>
        <?php endwhile; ?>
      </div>
    </div>

    <div class="col-md-6 mb-4">
      <div class="d-flex justify-content-between align-items-center">
        <h2><?php echo $apartment['name']; ?></h2>
        <button class="btn btn-light favorite-button" data-apartment-id="<?php echo $apartment['id']; ?>">
          <i class="fas fa-heart <?php echo $is_favorite ? 'text-danger' : 'gray'; ?>"></i>
        </button>
      </div>
      <p><strong>Адрес:</strong> <?php echo $apartment['address']; ?></p>
      <p><strong>Этаж:</strong> <?php echo $apartment['floor']; ?></p>
      <p><strong>Площадь:</strong> <?php echo $apartment['area']; ?> м²</p>
      <p><strong>Количество комнат:</strong> <?php echo $apartment['rooms']; ?></p>
      <p><strong>Цена:</strong> <?php echo number_format($apartment['price'], 0, ',', ' '); ?> руб.</p>
      <p><strong>Описание:</strong> <?php echo $apartment['description']; ?></p>
      <a href="chatuser.php?apartment_id=<?php echo $apartment_id; ?>" class="btn btn-primary btn-lg mt-3">Написать</a>
    </div>
  </div>
</main>

<script type="text/javascript">
  $(document).ready(function(){
    $('.property-slider').slick({
      dots: true,
      arrows: true,
      infinite: true,
      speed: 300,
      slidesToShow: 1,
      adaptiveHeight: true
    });
  });
  document.addEventListener('DOMContentLoaded', function () {
    const favoriteButtons = document.querySelectorAll('.favorite-button');

    favoriteButtons.forEach(button => {
      button.addEventListener('click', function () {
        <?php if (!isset($_SESSION['user_id'])): ?>
          alert("Необходимо авторизоваться");
          return;
        <?php endif; ?>

        const apartmentId = this.getAttribute('data-apartment-id');
        const heartIcon = this.querySelector('i');

        fetch('add_to_favorites.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: `apartment_id=${apartmentId}`,
        })
          .then(response => response.text())
          .then(data => {
            if (data.includes("Добавлено")) {
              heartIcon.classList.remove('gray'); // Убираем серый цвет
              heartIcon.classList.add('text-danger'); // Добавляем красный цвет
            } else if (data.includes("Удалено")) {
              heartIcon.classList.remove('text-danger'); // Убираем красный цвет
              heartIcon.classList.add('gray'); // Добавляем серый цвет
            }
          })
          .catch(error => console.error('Ошибка:', error));
      });
    });
  });
</script>

<?php include 'footer.php'; ?>
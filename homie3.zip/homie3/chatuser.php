<?php
include 'header.php';
include 'db.php';

// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Получаем ID админа
$admin_id_query = "SELECT id FROM users WHERE role = 'admin' LIMIT 1";
$admin_id_result = $conn->query($admin_id_query);
$admin_id = $admin_id_result->fetch_assoc()['id'];

// Получаем ID квартиры, если он передан
$apartment_id = isset($_GET['apartment_id']) ? (int)$_GET['apartment_id'] : null;

// Получение информации о квартире, если apartment_id передан
$apartment_info = null;
if ($apartment_id) {
    $apartment_query = "SELECT * FROM apartments WHERE id = $apartment_id";
    $apartment_result = $conn->query($apartment_query);
    $apartment_info = $apartment_result->fetch_assoc();
}

// Обработка отправки сообщения
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $message = $_POST['message'];
    $sender_id = $_SESSION['user_id'];
    $receiver_id = $admin_id;

    // Добавляем apartment_id в сообщение, если он есть
    $query = "INSERT INTO messages (sender_id, receiver_id, message, apartment_id) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('iisi', $sender_id, $receiver_id, $message, $apartment_id);

    if ($stmt->execute()) {
        // Перенаправляем, чтобы избежать повторной отправки при обновлении страницы
        header('Location: chatuser.php?apartment_id=' . $apartment_id);
        exit;
    }
}

// Получение сообщений для текущего пользователя
$user_id = $_SESSION['user_id'];
$messages_query = "SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at ASC";
$stmt = $conn->prepare($messages_query);
$stmt->bind_param('iiii', $user_id, $admin_id, $admin_id, $user_id);
$stmt->execute();
$messages_result = $stmt->get_result();
?>

<main>
  <div class="container my-5">
    <h2 class="text-center mb-4">Чат с агентом</h2>

    <!-- Отображение информации о квартире, если apartment_id передан -->
    <?php if ($apartment_info): ?>
      <div class="card mb-4">
        <div class="card-body">
          <h5 class="card-title">Информация о квартире</h5>
          <p><strong>Название:</strong> <?php echo htmlspecialchars($apartment_info['name']); ?></p>
          <p><strong>Адрес:</strong> <?php echo htmlspecialchars($apartment_info['address']); ?></p>
          <p><strong>Цена:</strong> <?php echo number_format($apartment_info['price'], 0, ',', ' '); ?> руб.</p>
          <p><strong>Описание:</strong> <?php echo htmlspecialchars($apartment_info['description']); ?></p>
        </div>
      </div>
    <?php endif; ?>


<!-- Список сообщений -->
<div class="row mt-5">
      <div class="col-md-8 mx-auto">
        <h3 class="text-center mb-4">Сообщения</h3>
        <div id="messages-list" class="list-group">
          <?php while ($message = $messages_result->fetch_assoc()): ?>
            <div class="list-group-item <?php echo $message['sender_id'] == $user_id ? 'text-end' : 'text-start'; ?>">
              <p><?php echo htmlspecialchars($message['message']); ?></p>
              <small class="text-muted"><?php echo $message['created_at']; ?></small>
            </div>
          <?php endwhile; ?>
        </div>
      </div>
    </div>

    <!-- Форма отправки сообщения -->
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card">
          <div class="card-body">
            <form id="chat-form">
              <div class="mb-3">
                <label for="message" class="form-label">Ваше сообщение</label>
                <textarea class="form-control" id="message" name="message" rows="1" required></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Отправить</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<script>
  // AJAX для отправки сообщения
  document.getElementById('chat-form').addEventListener('submit', function (e) {
    e.preventDefault(); // Отменяем стандартную отправку формы

    const messageInput = document.getElementById('message');
    const message = messageInput.value.trim();

    if (message === '') {
      alert('Введите сообщение');
      return;
    }

    // Отправляем сообщение через AJAX
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'send_message.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function () {
      if (xhr.status === 200) {
        // Очищаем поле ввода
        messageInput.value = '';

        // Добавляем новое сообщение в список
        const messagesList = document.getElementById('messages-list');
        const newMessage = document.createElement('div');
        newMessage.className = 'list-group-item text-end';
        newMessage.innerHTML = `
          <p>${message}</p>
          <small class="text-muted">Только что</small>
        `;
        messagesList.appendChild(newMessage);

        // Прокручиваем список сообщений вниз
        messagesList.scrollTop = messagesList.scrollHeight;
      } else {
        alert('Ошибка при отправке сообщения');
      }
    };
    xhr.send(`message=${encodeURIComponent(message)}&receiver_id=<?php echo $admin_id; ?>&apartment_id=<?php echo $apartment_id; ?>`);
  });
</script>

<?php include 'footer.php'; ?>
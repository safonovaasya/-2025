<?php
include 'header.php';
include 'db.php';

// Получение параметров фильтрации из GET-запроса
$priceFrom = isset($_GET['priceFrom']) && $_GET['priceFrom'] !== '' ? (int)$_GET['priceFrom'] : null;
$priceTo = isset($_GET['priceTo']) && $_GET['priceTo'] !== '' ? (int)$_GET['priceTo'] : null;
$propertyType = isset($_GET['propertyType']) && $_GET['propertyType'] !== '' ? $_GET['propertyType'] : null;
$action = isset($_GET['action']) && $_GET['action'] !== '' ? $_GET['action'] : null;
$rooms = isset($_GET['rooms']) && $_GET['rooms'] !== '' ? $_GET['rooms'] : null;

// Базовый SQL-запрос
$query = "SELECT a.id, a.name, a.price, a.address, p.photo_path
          FROM apartments a
          LEFT JOIN (SELECT apartment_id, MIN(id) as min_id FROM photos GROUP BY apartment_id) as min_photos
          ON a.id = min_photos.apartment_id
          LEFT JOIN photos p ON min_photos.min_id = p.id
          WHERE 1=1";

// Добавление условий фильтрации
if ($priceFrom !== null) {
    $query .= " AND a.price >= $priceFrom";
}
if ($priceTo !== null) {
    $query .= " AND a.price <= $priceTo";
}
if ($priceFrom !== null && $priceTo !== null && $priceFrom > $priceTo) {
    echo '<div class="col-md-12">
            <div class="alert alert-danger" role="alert">
              Минимальная цена не может быть больше максимальной.
            </div>
          </div>';
}
if ($propertyType !== null) {
    $query .= " AND a.type = '$propertyType'";
}
if ($action !== null) {
    $query .= " AND a.action = '$action'";
}
if ($rooms !== null) {
    if ($rooms === 'studio') {
        $query .= " AND a.rooms = 0"; // Студия
    } elseif ($rooms === '4+') {
        $query .= " AND a.rooms >= 4"; // 4+ комнат
    } else {
        $query .= " AND a.rooms = $rooms"; // 1, 2, 3 комнаты
    }
}

// Выполнение запроса
$result = $conn->query($query);

// Проверка на ошибки выполнения запроса
if (!$result) {
    die("Ошибка выполнения запроса: " . $conn->error);
}

// Получение списка избранных квартир для текущего пользователя
$favorites = [];
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $favorite_query = "SELECT apartment_id FROM favorites WHERE user_id = $user_id";
    $favorite_result = $conn->query($favorite_query);
    while ($row = $favorite_result->fetch_assoc()) {
        $favorites[] = $row['apartment_id'];
    }
}
?>

<main>
  <div class="container my-5">
    <h2 class="text-center mb-4">Недвижимость в Алейске</h2>

    <!-- Фильтры -->
    <div class="row mb-4">
      <div class="col-md-12">
        <div class="card p-3">
          <form method="GET" action="catalog.php">
            <div class="row">
              <!-- Цена от и до -->
              <div class="col-md-2">
                <label for="priceFrom" class="form-label">Цена от</label>
                <input type="number" class="form-control" id="priceFrom" name="priceFrom" placeholder="Мин" value="<?php echo $priceFrom; ?>">
              </div>
              <div class="col-md-2">
                <label for="priceTo" class="form-label">Цена до</label>
                <input type="number" class="form-control" id="priceTo" name="priceTo" placeholder="Макс" value="<?php echo $priceTo; ?>">
              </div>

              <!-- Тип недвижимости -->
              <div class="col-md-3">
                <label for="propertyType" class="form-label">Тип недвижимости</label>
                <select class="form-select" id="propertyType" name="propertyType">
                  <option value="">Все</option>
                  <option value="apartment">Квартира</option>
                  <option value="house">Дом</option>
                </select>
              </div>

              <!-- Действие -->
              <div class="col-md-2">
                <label for="action" class="form-label">Действие</label>
                <select class="form-select" id="action" name="action">
                  <option value="">Все</option>
                  <option value="rent">Снять</option>
                  <option value="buy">Купить</option>
                </select>
              </div>

              <!-- Количество комнат -->
              <div class="col-md-3">
                <label for="rooms" class="form-label">Количество комнат</label>
                <select class="form-select" id="rooms" name="rooms">
                  <option value="">Все</option>
                  <option value="studio">Студия</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4+">4+</option>
                </select>
              </div>
            </div>
            <div class="d-flex justify-content-center mt-3">
              <button type="submit" class="btn btn-primary filter-button">Фильтровать</button>
              <a href="catalog.php" class="btn btn-primary filter-button">Сбросить</a>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Список квартир -->
    <div class="row">
      <?php if ($result->num_rows > 0): ?>
        <?php while ($row = $result->fetch_assoc()): ?>
          <div class="col-md-4 mb-4">
            <div class="card h-100">
              <img src="<?php echo $row['photo_path']; ?>" class="card-img-top" alt="Квартира">
              <div class="card-body d-flex flex-column">
                <div class="d-flex justify-content-between align-items-center">
                  <h5 class="card-name"><?php echo $row['name']; ?></h5>
                  <button class="btn btn-light favorite-button" data-apartment-id="<?php echo $row['id']; ?>">
                    <i class="fas fa-heart <?php echo in_array($row['id'], $favorites) ? 'text-danger' : 'gray'; ?>"></i>
                  </button>
                </div>
                <h5 class="card-title"><?php echo number_format($row['price'], 0, ',', ' '); ?> руб.</h5>
                <p class="card-text"><?php echo $row['address']; ?></p>
                <a href="flat.php?id=<?php echo $row['id']; ?>" class="btn btn-primary mt-auto">Подробнее</a>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <div class="col-md-12">
          <div class="alert alert-info" role="alert">
            По вашему запросу ничего не найдено.
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</main>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    const favoriteButtons = document.querySelectorAll('.favorite-button');

    favoriteButtons.forEach(button => {
      button.addEventListener('click', function () {
        <?php if (!isset($_SESSION['user_id'])): ?>
          alert("Необходимо авторизоваться");
          return;
        <?php endif; ?>

        const apartmentId = this.getAttribute('data-apartment-id');
        const heartIcon = this.querySelector('i');

        fetch('add_to_favorites.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: `apartment_id=${apartmentId}`,
        })
          .then(response => response.text())
          .then(data => {
            if (data.includes("Добавлено")) {
              heartIcon.classList.remove('gray'); // Убираем серый цвет
              heartIcon.classList.add('text-danger'); // Добавляем красный цвет
            } else if (data.includes("Удалено")) {
              heartIcon.classList.remove('text-danger'); // Убираем красный цвет
              heartIcon.classList.add('gray'); // Добавляем серый цвет
            }
          })
          .catch(error => console.error('Ошибка:', error));
      });
    });
  });
</script>

<?php include 'footer.php'; ?>
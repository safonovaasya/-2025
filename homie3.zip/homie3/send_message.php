<?php
session_start();
include 'db.php';

// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    http_response_code(403); // Запрещено
    exit;
}

// Получаем данные из AJAX-запроса
$message = $_POST['message'];
$receiver_id = $_POST['receiver_id'];
$apartment_id = isset($_POST['apartment_id']) ? (int)$_POST['apartment_id'] : null;
$sender_id = $_SESSION['user_id'];

// Вставляем сообщение в базу данных
$query = "INSERT INTO messages (sender_id, receiver_id, message, apartment_id) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param('iisi', $sender_id, $receiver_id, $message, $apartment_id);

if ($stmt->execute()) {
    http_response_code(200); // Успешно
} else {
    http_response_code(500); // Ошибка сервера
}
?>
<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['email']) && isset($_GET['new_password'])) {
    $email = $_GET['email'];
    $new_password = password_hash($_GET['new_password'], PASSWORD_DEFAULT);

    $sql = "UPDATE users SET password = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $new_password, $email);

    if ($stmt->execute()) {
        header("Location: login.php");
        exit();
    } else {
        echo "Ошибка при обновлении пароля: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Неверный запрос.";
}
?>

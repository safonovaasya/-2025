<?php
include 'db.php';

if (isset($_GET['email'])) {
    $email = $_GET['email'];

    $sql = "SELECT security_question FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $security_question = $user['security_question'];
    } else {
        echo "Не такой почты в базе данных.";
        exit();
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Неверный запрос.";
    exit();
}
?>

<?php include 'header.php'; ?>

<!-- Основное содержимое страницы -->
<section class="container-fluid min-vh-100 d-flex align-items-center justify-content-center">
    <div class="row w-100">
        <div class="col-12 d-flex align-items-center justify-content-center">
            <div class="px-4 sign-container w-100 mx-auto" style="max-width: 500px;">
                <div class="text-center mt-5">
                    <h2 class="fw-bold brand fs-1 my-4">Вопрос безопасности</h2>
                    <div class="mb-2 mx-auto signin-border"></div>
                    <!-- Форма для ответа на вопрос безопасности -->
                    <form action="verify_security_answer.php" method="POST">
                        <input type="hidden" name="email" value="<?php echo $email; ?>">
                        <div class="position-relative my-4">
                            <label for="security_question" class="control-label"><?php echo $security_question; ?></label>
                            <input class="form-control inputbox shadow-none p-2" type="text" name="security_answer" id="security_answer" required>
                        </div>
                        <button type="submit" class="btn my-5 fw-bold btn-lg sign-up rounded-5 px-5 fs-6">Продолжить</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>

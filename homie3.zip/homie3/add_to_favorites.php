<?php
session_start();
include 'db.php';

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    echo "Необходимо авторизоваться";
    exit;
}

// Получение данных из запроса
$apartment_id = isset($_POST['apartment_id']) ? (int)$_POST['apartment_id'] : null;

if (!$apartment_id) {
    echo "Ошибка: ID квартиры не указан";
    exit;
}

$user_id = $_SESSION['user_id'];

// Проверка, добавлена ли уже квартира в избранное
$query = "SELECT id FROM favorites WHERE user_id = $user_id AND apartment_id = $apartment_id";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    // Удаление из избранного
    $query = "DELETE FROM favorites WHERE user_id = $user_id AND apartment_id = $apartment_id";
    $conn->query($query);
    echo "Удалено из избранного";
} else {
    // Добавление в избранное
    $query = "INSERT INTO favorites (user_id, apartment_id) VALUES ($user_id, $apartment_id)";
    $conn->query($query);
    echo "Добавлено в избранное";
}
?>
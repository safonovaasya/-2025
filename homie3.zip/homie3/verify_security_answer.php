<?php
include 'db.php';

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $security_answer = $_POST['security_answer'];

    $sql = "SELECT * FROM users WHERE email = ? AND security_answer = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $security_answer);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Перенаправляем на страницу сброса пароля
        header("Location: reset_password_form.php?email=" . urlencode($email));
        exit();
    } else {
        $error_message = "Неверный ответ на вопрос безопасности.";
    }

    $stmt->close();
    $conn->close();
}
?>

<?php include 'header.php'; ?>

<!-- Основное содержимое страницы -->
<section class="container-fluid min-vh-100 d-flex align-items-center justify-content-center">
    <div class="row w-100">
        <div class="col-12 d-flex align-items-center justify-content-center">
            <div class="px-4 sign-container w-100 mx-auto" style="max-width: 500px;">
                <div class="text-center mt-5">
                    <h2 class="fw-bold brand fs-1 my-4">Проверка ответа</h2>
                    <div class="mb-2 mx-auto signin-border"></div>
                    <!-- Форма для проверки ответа -->
                    <form action="verify_security_answer.php" method="POST">
                        <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
                        <div class="position-relative my-4">
                            <label for="security_answer" class="control-label">Введите ответ на вопрос безопасности:</label>
                            <input class="form-control inputbox shadow-none p-2" type="text" name="security_answer" id="security_answer" required>
                        </div>
                        <button type="submit" class="btn my-5 fw-bold btn-lg sign-up rounded-5 px-5 fs-6">Продолжить</button>
                    </form>
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>

<?php
include 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_role'] = $user['role'];
            header("Location: index.php");
            exit();
        } else {
            $error_message = "Неверный пароль.";
        }
    } else {
        $error_message = "Пользователь не найден.";
    }

    $stmt->close();
    $conn->close();
}
?>

<?php include 'header.php'; ?>

<!-- Основное содержимое страницы -->
<section class="container-fluid min-vh-100 d-flex align-items-center justify-content-center">
    <div class="row w-100">
        <div class="col-12 d-flex align-items-center justify-content-center">
            <div class="px-4 sign-container w-100 mx-auto" style="max-width: 500px;">
                <div class="text-center mt-5">
                    <h2 class="fw-bold brand fs-1 my-4">Вход в личный кабинет</h2>
                    <div class="mb-2 mx-auto signin-border"></div>
                    <!-- Форма для входа -->
                    <form action="login.php" method="POST">
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="email" name="email" id="email" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="email" class="control-label">Электронная почта</label>
                            </div>
                        </div>
                        <div class="position-relative my-5">
                            <input class="form-control inputbox shadow-none p-2" type="password" name="password" id="password" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="password" class="control-label">Пароль</label>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mx-auto">
                            <a href="forgot_password.php" class="text-reset text-decoration-none fw-bold">Забыли пароль?</a>
                        </div>
                        <button type="submit" class="btn my-5 fw-bold btn-lg sign-up rounded-5 px-5 fs-6">Войти</button>
                    </form>
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <div class="text-center mt-3">
                        <p class="fs-6">Нет аккаунта? <a href="register.php" class="text-reset fw-bold">Зарегистрируйтесь</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>

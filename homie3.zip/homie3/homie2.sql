-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 05 2025 г., 17:19
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `homie2`
--

-- --------------------------------------------------------

--
-- Структура таблицы `apartments`
--

CREATE TABLE `apartments` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `address` varchar(255) NOT NULL,
  `floor` int NOT NULL,
  `area` decimal(5,2) NOT NULL,
  `rooms` int NOT NULL,
  `description` text,
  `type` enum('apartment','house') DEFAULT 'apartment',
  `action` enum('rent','buy') DEFAULT 'buy'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `apartments`
--

INSERT INTO `apartments` (`id`, `name`, `price`, `address`, `floor`, `area`, `rooms`, `description`, `type`, `action`) VALUES
(1, '2-к. квартира, 39,5 м², 5/5 эт.', '1500000.00', 'ул. Ленина, д. 12', 5, '39.50', 2, 'Описание квартиры 1', 'apartment', 'buy'),
(2, '3-к. квартира, 65,5 м², 7/16 эт.', '2300000.00', 'ул. Советская, д. 34', 7, '65.50', 3, 'Описание квартиры 2', 'apartment', 'rent'),
(3, '3-к. дом, 80,5 м².', '3100000.00', 'ул. Мира, д. 56', 0, '20.50', 1, 'Описание квартиры 3', 'house', 'buy'),
(7, 'Студия, 25 м², 4/5 эт.', '19000.00', 'ул. Ширшова, д. 4', 4, '25.00', 0, 'Сдается студию, рядом школа и сад, монетка , аптека, кб, пункты выдачи озон вб. По мебели и техники все остается как на фото, колеса хозяин увезет. 19.000 руб. месяц  10.000 залог ,счетчики отдельно , все остальные услуги жку входят в стоимость', 'apartment', 'rent'),
(8, '2-к. дом, 35 м².', '1600000.00', 'ул. Олешко 81 кв. 2', 0, '55.00', 2, 'Продаётся 2-х комнатный дом на земле, в центре города Олешко 81 кв. 2\r\nБольшой зал, кухня из второй комнаты был сделан сан узел.\r\nСтоит котёл длительного горения в отдельном помещении. Две веранды, одна большая другая маленькая. Гараж, углярка.', 'house', 'buy'),
(9, '1-к. квартира, 31 м². 2/5 эт.', '21000.00', 'ул. Пионерская, 119 кв. 23', 2, '31.00', 1, 'Сдается однокомнатная квартира. 2/5 дома. косметический ремонт. на длительный срок. Цена 24000. Счетчики. Залог 6000, возвращается при выезде', 'apartment', 'rent');

-- --------------------------------------------------------

--
-- Структура таблицы `favorites`
--

CREATE TABLE `favorites` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `apartment_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `apartment_id`) VALUES
(43, 2, 7),
(44, 2, 9),
(45, 4, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE `messages` (
  `id` int NOT NULL,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `apartment_id` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`id`, `sender_id`, `receiver_id`, `message`, `created_at`, `is_read`, `apartment_id`) VALUES
(1, 4, 2, 'привет!', '2025-02-23 05:11:47', 0, NULL),
(2, 2, 4, 'здравствуйте! чем могу вам помочь?', '2025-02-23 05:12:58', 0, NULL),
(3, 4, 2, 'я бы хотела, чтобы вы мне помогли с продажей дома', '2025-02-23 05:16:14', 0, NULL),
(5, 2, 4, 'отлично! расскажите о ваших условиях или можем встретиться лично\r\n', '2025-02-23 05:24:49', 0, NULL),
(6, 4, 2, 'давайте лично, так будет удобнее!', '2025-02-23 05:26:14', 0, NULL),
(8, 2, 4, 'хорошо, в любой будний день можете прийти по адресу ул. Ширшова, д. 55, будем вас ждать!', '2025-02-23 05:31:48', 0, NULL),
(10, 4, 2, 'хорошо, спасибо!', '2025-02-23 05:34:56', 0, NULL),
(11, 2, 4, 'да пожалуйста!', '2025-02-23 05:36:20', 0, NULL),
(12, 4, 2, 'привет!', '2025-02-23 05:38:04', 0, NULL),
(13, 2, 4, 'мы ждем вас', '2025-02-23 05:43:52', 0, NULL),
(14, 4, 2, 'хорошо', '2025-02-23 05:44:05', 0, NULL),
(28, 6, 2, 'привет, мне понравилась эта студия', '2025-02-23 07:51:58', 0, 6),
(29, 6, 2, 'да', '2025-02-23 07:52:47', 0, 6),
(34, 1, 2, 'Привет, хочу посмотреть эту квартиру', '2025-02-24 15:14:24', 0, 1),
(35, 8, 2, 'привет, хочу эту квартиру снять', '2025-02-26 15:08:07', 0, 6),
(37, 2, 1, 'Добрый день! Да, конечно, когда Вам будет удобно?', '2025-02-26 15:26:45', 0, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

CREATE TABLE `photos` (
  `id` int NOT NULL,
  `apartment_id` int NOT NULL,
  `photo_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `photos`
--

INSERT INTO `photos` (`id`, `apartment_id`, `photo_path`) VALUES
(1, 1, 'img/apartment1.jpg'),
(2, 1, 'img/apartment1.jpg'),
(3, 2, 'img/apartment2.jpg'),
(4, 2, 'img/apartment2.jpg'),
(5, 3, 'img/apartment3.jpg'),
(6, 3, 'img/apartment3.jpg'),
(14, 7, 'img/apart4.jpg'),
(15, 7, 'img/apart5.jpg'),
(16, 7, 'img/apart6.jpg'),
(17, 8, 'img/apart7.webp'),
(18, 8, 'img/apart8.webp'),
(19, 8, 'img/apart9.webp'),
(20, 8, 'img/apart10.webp'),
(21, 9, 'img/apart11.jpg'),
(22, 9, 'img/apart12.jpg'),
(23, 9, 'img/apart13.jpg'),
(24, 9, 'img/apart14.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `reviews`
--

CREATE TABLE `reviews` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `review_text` text NOT NULL,
  `status` enum('pending','approved') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `reviews`
--

INSERT INTO `reviews` (`id`, `name`, `review_text`, `status`) VALUES
(1, 'Ася ', 'Очень выручили, сделка прошла удачно и быстро. Спасибо!', 'approved'),
(3, 'Побегова Настя', 'Быстро помогли найти квартиру, спасибо!', 'approved');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `security_question` varchar(255) DEFAULT NULL,
  `security_answer` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `security_question`, `security_answer`) VALUES
(1, 'Побегова Настя', 'nanana@nana', '$2y$10$HZ/SpyiGnCpiZBFcDyRmP.6ceBXsEcuB4WUKNm1l9ud/G7cXUry2e', 'user', '2025-02-20 14:17:12', NULL, NULL),
(2, 'админ', 'admin@admin', '$2y$10$xBWfyZ8DPXRAPCN6vfrY8ur2Ah033.Zde8CBerPajnvtL6xhb/FIe', 'admin', '2025-02-20 14:34:38', NULL, NULL),
(3, 'Ася', 'asya.safonova53@gmail.com', '$2y$10$db3ToHhC1AolXwC5R57nm.Vqh..j6/5sQwbT397v.XMRbwG8IGDum', 'user', '2025-02-20 14:39:33', NULL, NULL),
(4, 'Сафонова Валерия', 'safonova.asya04@mail.ru', '$2y$10$qkZEMDk5.s8n3OjpJwzMd.mHA5ciwWJ5IHu2QvF97F.z60qTqSuti', 'user', '2025-02-21 13:34:39', NULL, NULL),
(5, 'Иванов Иван', 'fghjk@mail.ru', '$2y$10$jtUHB3h917cJTqOStoJfVeRgQ1UU8u9U0eZIg/z5OYElR7fxsjYVG', 'user', '2025-02-21 16:48:07', 'Ваш любимый вид спорта?', 'футбол'),
(6, 'Семакин Саша', '111@111', '$2y$10$mew89z03bpEH1s4dhN.ft.lDe5IYc6bbure1D/fm3s5SEvzvgB.JG', 'user', '2025-02-23 05:54:21', 'Имя вашего соседа в детстве?', 'Витя'),
(7, 'Даниил', 'ddd@ddd', '$2y$10$KsJ0B9/i3Gd5FVCQLSXeI.HuFyVATE6sSw1Fodni94yr20XDd18wq', 'user', '2025-02-23 07:55:27', 'Ваше любимое дерево?', 'дуб'),
(8, 'Мергеенко Сергей', '333@333', '$2y$10$.hE0ZJBqVMziZQDU74h4FuaIy6YQpZWHLy1gJfXkxU4TYc0O8eljC', 'user', '2025-02-26 15:07:25', 'Имя вашего кумира в детстве?', 'Барби'),
(9, 'Кирилл', 'kirilla06@mail.ru', '$2y$10$F8m7IybOKY2jHGG3wg0Sn.O2P2.SzE.ZqRJiNRow.zsp6wzqYM732', 'user', '2025-03-03 16:06:14', 'Имя вашего крестного отца или крестной матери?', 'Коля');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `apartments`
--
ALTER TABLE `apartments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `apartment_id` (`apartment_id`);

--
-- Индексы таблицы `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `receiver_id` (`receiver_id`);

--
-- Индексы таблицы `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `apartment_id` (`apartment_id`);

--
-- Индексы таблицы `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `apartments`
--
ALTER TABLE `apartments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT для таблицы `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT для таблицы `photos`
--
ALTER TABLE `photos`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT для таблицы `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `favorites_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favorites_ibfk_2` FOREIGN KEY (`apartment_id`) REFERENCES `apartments` (`id`) ON DELETE CASCADE;

--
-- Ограничения внешнего ключа таблицы `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `photos`
--
ALTER TABLE `photos`
  ADD CONSTRAINT `photos_ibfk_1` FOREIGN KEY (`apartment_id`) REFERENCES `apartments` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

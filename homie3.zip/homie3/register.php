<?php
include 'db.php';

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $security_question = $_POST['security_question'];
    $security_answer = $_POST['security_answer'];

    // Проверка совпадения паролей
    if ($password !== $confirm_password) {
        $error_message = "Пароли различаются.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $role = 'user'; // По умолчанию роль пользователя

        $sql = "INSERT INTO users (name, email, password, role, security_question, security_answer) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $name, $email, $hashed_password, $role, $security_question, $security_answer);

        if ($stmt->execute()) {
            header("Location: login.php");
            exit();
        } else {
            $error_message = "Ошибка: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    }
}
?>

<?php include 'header.php'; ?>

<!-- Основное содержимое страницы -->
<section class="container-fluid min-vh-100 d-flex align-items-center justify-content-center">
    <div class="row w-100">
        <div class="col-12 d-flex align-items-center justify-content-center">
            <div class="px-4 sign-container w-100 mx-auto" style="max-width: 500px;">
                <div class="text-center mt-5">
                    <h2 class="fw-bold brand fs-1 my-4">Регистрация</h2>
                    <div class="mb-2 mx-auto signin-border"></div>
                    <!-- Форма для регистрации -->
                    <form action="register.php" method="POST">
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="text" name="name" id="name" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="name" class="control-label">Имя</label>
                            </div>
                        </div>
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="email" name="email" id="email" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="email" class="control-label">Электронная почта</label>
                            </div>
                        </div>
                        <div class="position-relative my-4">
                            <select class="form-control inputbox shadow-none p-2" name="security_question" id="security_question" required>
                                <option value="">Выберите вопрос</option>
                                <option value="Имя вашего кумира в детстве?">Имя вашего кумира в детстве?</option>
                                <option value="Ваш любимый вид спорта?">Ваш любимый вид спорта?</option>
                                <option value="Название вашей первой школы?">Название вашей первой школы?</option>
                                <option value="Имя вашего крестного отца или крестной матери?">Имя вашего крестного отца или крестной матери?</option>
                                <option value="Ваше любимое время года?">Ваше любимое время года?</option>
                                <option value="Название вашего любимого музыкального инструмента?">Название вашего любимого музыкального инструмента?</option>
                                <option value="Имя вашего соседа в детстве?">Имя вашего соседа в детстве?</option>
                                <option value="Ваше любимое дерево?">Ваше любимое дерево?</option>
                            </select>
                        </div>
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="text" name="security_answer" id="security_answer" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="security_answer" class="control-label">Ответ на вопрос</label>
                            </div>
                        </div>
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="password" name="password" id="password" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="password" class="control-label">Пароль</label>
                            </div>
                        </div>
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="password" name="confirm_password" id="confirm_password" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="confirm_password" class="control-label">Подтвердите пароль</label>
                            </div>
                        </div>
                        <div id="passwordError" class="text-danger"><?php echo $error_message; ?></div>
                        <button type="submit" class="btn my-5 fw-bold btn-lg sign-up rounded-5 px-5 fs-6">Зарегистрироваться</button>
                    </form>
                    <div class="text-center mt-3">
                        <p class="fs-6">Уже есть аккаунт? <a href="login.php" class="text-reset fw-bold">Войдите</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.getElementById('confirm_password').addEventListener('input', function() {
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirm_password').value;
    var passwordError = document.getElementById('passwordError');

    if (password !== confirmPassword) {
        passwordError.textContent = "Пароли различаются.";
    } else {
        passwordError.textContent = "";
    }
});
</script>

<?php include 'footer.php'; ?>

<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Перенаправляем на страницу с вопросом безопасности
        header("Location: security_question.php?email=" . urlencode($email));
        exit();
    } else {
        $error_message = "Нет такой почты в базе данных.";
    }

    $stmt->close();
    $conn->close();
}
?>

<?php include 'header.php'; ?>

<!-- Основное содержимое страницы -->
<section class="container-fluid min-vh-100 d-flex align-items-center justify-content-center">
    <div class="row w-100">
        <div class="col-12 d-flex align-items-center justify-content-center">
            <div class="px-4 sign-container w-100 mx-auto" style="max-width: 500px;">
                <div class="text-center mt-5">
                    <h2 class="fw-bold brand fs-1 my-4">Восстановление пароля</h2>
                    <div class="mb-2 mx-auto signin-border"></div>
                    <!-- Форма для восстановления пароля -->
                    <form action="forgot_password.php" method="POST">
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="email" name="email" id="email" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="email" class="control-label">Электронная почта</label>
                            </div>
                        </div>
                        <button type="submit" class="btn my-5 fw-bold btn-lg sign-up rounded-5 px-5 fs-6">Продолжить</button>
                    </form>
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include 'footer.php'; ?>

<?php
ob_start(); 
session_start();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="apple-touch-icon" sizes="180x180" href="img/favicon/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="img/favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="img/favicon/favicon-16x16.png">
  <link rel="manifest" href="img/favicon/site.webmanifest">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <link rel="stylesheet" href="styles.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css"/>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css"/>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
  <title>Homie</title>
  <meta name="description" content="Шаблон навигационной панели для новостного сайта">
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark p-0 m-0" aria-label="Основная навигация">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php">
        <img src="img/logo.png" alt="логотип" class="logo">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Переключить навигацию">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link mx-2" aria-current="page" href="index.php">Главная</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-2" href="catalog.php">Каталог</a>
          </li>
          <?php if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin'): ?>
            <li class="nav-item">
              <a class="nav-link mx-2" href="services.php">Услуги</a>
            </li>
          <?php endif; ?>
          <?php if (isset($_SESSION['user_id'])): ?>
            <?php if ($_SESSION['user_role'] == 'admin'): ?>
              <li class="nav-item">
                <a class="nav-link mx-2" href="favorites.php">Избранное</a>
              </li>
              <li class="nav-item">
                <a class="nav-link mx-2" href="admin_panel.php">Админ-панель</a>
              </li>
              <li class="nav-item">
                <a class="nav-link mx-2" href="chat.php">Чат</a>
              </li>
            <?php else: ?>
              <li class="nav-item">
                <a class="nav-link mx-2" href="favorites.php">Избранное</a>
              </li>
              <li class="nav-item">
                <a class="nav-link mx-2" href="chatuser.php">Написать агенту</a>
              </li>
            <?php endif; ?>
            <li class="nav-item">
              <a class="nav-link mx-2" href="logout.php">Выйти</a>
            </li>
          <?php endif; ?>
          <li class="nav-item flare">
            <a class="nav-link mx-2" href="<?php echo isset($_SESSION['user_id']) ? 'profile.php' : 'login.php'; ?>">
              Личный кабинет<span class="ms-2">&#x2192;</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('.testimonials-slider').slick({
        dots: true,
        infinite: true,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        adaptiveHeight: true
      });
    });
  </script>
</body>
</html>
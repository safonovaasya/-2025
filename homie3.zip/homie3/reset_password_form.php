<?php
include 'db.php';

$error_message = "";

if (isset($_GET['email'])) {
    $email = $_GET['email'];
} else {
    echo "Неверный запрос.";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $error_message = "Пароли различаются.";
    } else {
        // Перенаправляем на страницу обновления пароля
        header("Location: update_password.php?email=" . urlencode($email) . "&new_password=" . urlencode($new_password));
        exit();
    }
}
?>

<?php include 'header.php'; ?>

<!-- Основное содержимое страницы -->
<section class="container-fluid min-vh-100 d-flex align-items-center justify-content-center">
    <div class="row w-100">
        <div class="col-12 d-flex align-items-center justify-content-center">
            <div class="px-4 sign-container w-100 mx-auto" style="max-width: 500px;">
                <div class="text-center mt-5">
                    <h2 class="fw-bold brand fs-1 my-4">Сброс пароля</h2>
                    <div class="mb-2 mx-auto signin-border"></div>
                    <!-- Форма для сброса пароля -->
                    <form action="reset_password_form.php?email=<?php echo urlencode($email); ?>" method="POST" id="passwordForm">
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="password" name="new_password" id="new_password" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="new_password" class="control-label">Новый пароль</label>
                            </div>
                        </div>
                        <div class="position-relative my-4">
                            <input class="form-control inputbox shadow-none p-2" type="password" name="confirm_password" id="confirm_password" required>
                            <div class="input-label position-absolute px-2 bg-white z-1">
                                <label for="confirm_password" class="control-label">Подтвердите пароль</label>
                            </div>
                        </div>
                        <div id="passwordError" class="text-danger"><?php echo $error_message; ?></div>
                        <button type="submit" class="btn my-5 fw-bold btn-lg sign-up rounded-5 px-5 fs-6">Сбросить пароль</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.getElementById('confirm_password').addEventListener('input', function() {
    var password = document.getElementById('new_password').value;
    var confirmPassword = document.getElementById('confirm_password').value;
    var passwordError = document.getElementById('passwordError');

    if (password !== confirmPassword) {
        passwordError.textContent = "Пароли различаются.";
    } else {
        passwordError.textContent = "";
    }
});
</script>

<?php include 'footer.php'; ?>

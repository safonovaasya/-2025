<?php include 'header.php'; ?>

<main>
  <!-- Hero Section -->
  <section class="hero-section py-5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-6">
          <h1 class="display-4 fw-bold">Добро пожаловать в Homie</h1>
          <p class="lead">Мы предлагаем лучшие решения для аренды, покупки и продажи недвижимости.</p>
          <a href="catalog.php" class="btn btn-primary btn-lg">Посмотреть недвижимость</a>
        </div>
        <div class="col-md-6">
          <img src="img/hero1.jpg" alt="Hero Image" class="img-fluid rounded">
        </div>
      </div>
    </div>
  </section>

  <!-- Примеры услуг -->
  <section id="services" class="services-section py-5">
    <div class="container">
      <h2 class="text-center mb-5">Наши услуги</h2>
      <div class="row d-flex">
        <div class="col-md-4 d-flex">
          <div class="card flex-fill mb-4">
            <img src="img/service1.png" class="card-img-top" alt="Аренда недвижимости">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">Аренда недвижимости</h5>
              <p class="card-text">Широкий выбор квартир и домов для аренды.</p>
              <a href="services.php" class="btn btn-primary mt-auto">Подробнее</a>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-flex">
          <div class="card flex-fill mb-4">
            <img src="img/service2.png" class="card-img-top" alt="Покупка недвижимости">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">Покупка недвижимости</h5>
              <p class="card-text">Поможем найти дом вашей мечты.</p>
              <a href="services.php" class="btn btn-primary mt-auto">Подробнее</a>
            </div>
          </div>
        </div>
        <div class="col-md-4 d-flex">
          <div class="card flex-fill mb-4">
            <img src="img/service3.png" class="card-img-top" alt="Продажа недвижимости">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title">Продажа недвижимости</h5>
              <p class="card-text">Поможем продать вашу недвижимость быстро и выгодно.</p>
              <a href="services.php" class="btn btn-primary mt-auto">Подробнее</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Преимущества -->
  <section class="advantages-section py-5">
    <div class="container">
      <h2 class="text-center mb-5">Наши преимущества</h2>
      <div class="row text-center">
        <div class="col-md-4">
          <div class="icon-box">
            <i class="fas fa-check-circle fa-3x mb-3" style="color: #D3CAE2;"></i>
            <h4>Надежность</h4>
            <p>Мы гарантируем безопасность и надежность всех сделок.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="icon-box">
            <i class="fas fa-clock fa-3x mb-3" style="color: #D3CAE2;"></i>
            <h4>Экономия времени</h4>
            <p>Быстрый поиск и оформление документов.</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="icon-box">
            <i class="fas fa-hand-holding-usd fa-3x mb-3" style="color: #D3CAE2;"></i>
            <h4>Выгодные цены</h4>
            <p>Лучшие предложения на рынке недвижимости.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Отзывы -->
  <section class="testimonials-section py-5">
    <div class="container">
      <h2 class="text-center mb-5">Отзывы наших клиентов</h2>
      <div class="testimonials-slider">
        <?php
        include 'db.php';
        $reviews_query = "SELECT * FROM reviews WHERE status = 'approved' ORDER BY id DESC LIMIT 5;";
        $reviews_result = $conn->query($reviews_query);
        while ($review = $reviews_result->fetch_assoc()):
        ?>
          <div class="card mb-4">
            <div class="card-body">
              <p class="card-text"><?php echo $review['review_text']; ?></p>
              <footer class="blockquote-footer"><?php echo $review['name']; ?></footer>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
      <div class="text-center mt-4">
        <a href="<?php echo isset($_SESSION['user_id']) ? 'profile.php' : 'login.php'; ?>" class="btn btn-primary">Добавить отзыв</a>
      </div>
    </div>
  </section>
</main>

<?php include 'footer.php'; ?>
